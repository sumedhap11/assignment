import express from "express";
import mongoose from "mongoose";
import dbConnect from "../config/db.js";
import cors from "cors";

const APP = express();
APP.use(cors());
APP.use(express.json());
dbConnect()
  .then(function () {
    console.log("DB Connected");
  })
  .catch(function () {
    console.log("DB Connection Failed", err);
  });

//Preparing a schema for users collection
const kittySchema = new mongoose.Schema({
  name: String,
  age: Number,
  place: String,
});

const Kitten = mongoose.model("users", kittySchema);

APP.get("/users", async (req, res) => {
  try {
    let result = await Kitten.find();
    console.log(result);

    res.status(200).send(result);
  } catch (err) {
    res.status(403).send(err);
  }
});

APP.post("/users", async (req, res) => {
  console.log(req.body);
  try {
    await kitten.create(req.body);
    res.status(201).send({ msg: "User Added in DB" });
  } catch (err) {
    console.log(err);
    res.status(403).send(err);
  }
});
APP.put("/users/:userId", async (req, res) => {
  console.log(req.body, req.params.userId);
  try {
    await kitten.findByIdAndDelete(req.params.userId);
    res.send({ msg: "User Updated" });
  } catch (err) {
    console.log(err);
    res.status(403).send(err);
  }
});

APP.delete("/users/:userId", async (req, res) => {
  console.log(req.params.userId);
  try {
    await kitten.findByIdAndDelete(req.params.userId);
    res.send({ msg: "User Deleted" });
  } catch (err) {
    console.log(err);
    res.status(403).send(err);
  }
});

APP.listen(4005, function () {
  console.log("App Started");
});
