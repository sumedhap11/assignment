//Dom Event Listeners:

document.querySelector("button").addEventListener("click", function () {
  let cityName = document.getElementById("x1").value;
  if (cityName == "") {
    document.getElementById("result").innerHTML = "city name Required";
  } else {
      const APIKEY = "f5af6941ea761632d8ea91b8d4129f1d";
      const XHR = new XMLHttpRequest();
      console.log(XHR);
      console.log(XHR.readyState, XHR.status);
      const API = `https://api.openweathermap.org/data/2.5/weather?q=${cityName},IN&appid=${APIKEY}&units=metric`;
      XHR.onreadystatechange = function () { 
          console.log(XHR.readyState, XHR.status);
          if (XHR.readyState == 4 && XHR.status);
          if (XHR.readyState == 4 && XHR.status == 200) {
              let result = XHR.responseText;
              console.log(result);
              let info = JSON.parse(result);
              console.log(info);
              document.getElementById("result").innerHTML = `
              <b>Temperature</b>=${info.main.temp}<br/>
              <b>Wind Speed </b>=${info.wind.speed}<br/>`;
          }
      };
          
      XHR.open("GET", API);
      XHR.send();
  }
});

/* 
 Ahax
 Asyncronous java Script & xml
 It works on client side
 its  a technique,,uses existing technology
 (Java Script -for data transfer,HTML-css for Mark Up ,Prsentation)
 without reloading an 

 open("get",apiurl)--- to connect apis  or server side web pages
 send()--- send a request to the api or server

 readystate---it generates cycles from 0 to 4
 0-request is not initialized
 1-request has been setup(when you perform open() method)
 2-request has beeen sent to the  server(when you perform send() method)
 3-request is in progress mode on server side(i.e api is doing work)
 4-request cycle completed with response or error(values back to javascript)
 all state will be detected by "onreadystatechange" event

 final value from Api will be received 

 status codes:-
 200:ok(success)
 201:creation process
 404-page not found
 500- internal server error
 403:Forbidden access (for Auth process)
 301:moved permantly (page Redirection)
 400:Malfunction with Bad values status


*/


