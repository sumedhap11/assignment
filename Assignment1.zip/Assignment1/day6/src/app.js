import express from 'express'
import mongoose from "mongoose";
import dbconnect from "../config/db.js";

const APP = express();
APP.use(express.urlencoded());
dbconnect()
    .then(function(res){
    console.log("DB connected");
})
    .catch(function (err) {
        console.log(err);
    });
    const kittySchema = new mongoose.Schema({
      name: String,
      age: Number,
      place: String,
    });

    const Kitten = mongoose.model("users", kittySchema);
APP.get("/showusers",  async function (req, res) { 
    try {
        let result = await Kitten.find();
        res.render("show.ejs",{dataSet:result});
    } catch (err) {
        console.log(err)
    }
});

APP.get("/addusers", function (req, res) { 
    res.render("add.ejs");
});

APP.post("/user-action", async function (req, res) {
    console.log(req.body);
    try { 
        await Kitten.create(req.body);
        res.redirect("/showusers")
    } catch (err) {
        console.log(err);
    }
});
APP.listen(4000);