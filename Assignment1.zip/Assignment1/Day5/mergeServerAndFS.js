const FS = require("fs");
const HTTP = require("http");
const SERVER = HTTP.createServer((req, res) => {
  let fileName = "";
  if (req.url == "/") {
    fileName = "home.html";
  } else if (req.url == "/about-us") {
    fileName = "about.html";
  } else if (req.url == "/text") {
    fileName = "text.html";
  }
  FS.readFile(fileName, "utf-8", function (err, data) {
    if (!err) {
      res.end(data);
    }
  });
});
SERVER.listen(4001, function () {
  console.log("Server Started");
});
