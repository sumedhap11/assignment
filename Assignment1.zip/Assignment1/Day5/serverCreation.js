/*

*/
const HTTP = require("http");
//console.log(HTTP);
const server = HTTP.createServer(function (req, res) {
    res.end("Hello World");

});
server.listen(4000, function () {
    console.log("Server Started");
});


