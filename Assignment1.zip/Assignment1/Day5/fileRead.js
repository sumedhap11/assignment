const FS = require("fs");
console.log(FS);
console.log("File Reading Started");
let result = FS.readFileSync("Example.html","utf-8");
console.log(result);

console.log("file Reading End");